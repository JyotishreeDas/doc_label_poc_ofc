package com.kn.documentlabelling;



import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author mvidyadh
 *
 */
public class Test {

  /**
   * @param args
   * @throws ClassNotFoundException
   * @throws SQLException
   * @throws IOException
   */
  public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {

    Class.forName("com.mysql.jdbc.Driver");
    Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/documentlabelling_locenvdb", "root", "root");
    Statement st = cn.createStatement();
    
    File f1 = new File("d:\\waybill\\D84C71D4.png");
    FileInputStream fin = new FileInputStream(f1);
    PreparedStatement pst = cn.prepareStatement(
        "insert INTO FILES (id, file_name, file_size, file_content,modificationCounter) values ( 3 , 'D84C71D4.png' , '100' ,?,3 )");
    
   /* File f1 = new File("d:\\waybill\\jse-ctwaybill08.pdf");
    FileInputStream fin = new FileInputStream(f1);
    PreparedStatement pst = cn.prepareStatement(
        "insert INTO FILES (id, file_name, file_size, file_content,modificationCounter) values ( 8 , 'jse-ctwaybill08.pdf' , '100' ,?,2 )");*/
    pst.setBlob(1, fin, fin.available());
    pst.executeUpdate();
    fin.close();
    pst.close();
    cn.close();
  }

}
