package com.kn.documentlabelling.tool.service.impl.rest;

import java.io.IOException;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;

import com.kn.documentlabelling.dl.logic.api.Dl;
import com.kn.documentlabelling.tool.service.api.rest.DocumentLabellingRestApi;

/**
 * @author annjosep
 *
 */
@Named("DocumentLabellingRestService")
public class DocumentLabellingRestApiImpl implements DocumentLabellingRestApi {

  @Inject
  private Dl dl;

  @SuppressWarnings("javadoc")
  @Override
  public Response documentList() {

    return this.dl.findAllFiles();

    /*
     * UploadResult result = new UploadResult(); List<String> files = new ArrayList<String>(); try {
     *
     * Class.forName("com.mysql.jdbc.Driver"); Connection cn =
     * DriverManager.getConnection("jdbc:mysql://localhost:3306/aisservice_locEnvDB", "root", "admin"); Statement st =
     * cn.createStatement(); ResultSet resultSet = st.executeQuery("select file_name from aisservice_locEnvDB.FILES");
     * while (resultSet.next()) { String file_name = resultSet.getString("file_name"); files.add(file_name); }
     *
     * System.out.println("Files" + files);
     *
     * } catch (ClassNotFoundException e) { e.printStackTrace(); } catch (SQLException e) { e.printStackTrace(); }
     * result.setFiles(files);
     *
     * return Response.status(200).entity(result).build();
     */

  }

  @Override
  public Response documentContent(String fileName) throws IOException, SQLException {

    return this.dl.getDocumentContent(fileName);
  }
}
