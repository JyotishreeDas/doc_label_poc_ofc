package com.kn.documentlabelling.general.service.impl.rest;

import java.util.List;

/**
 * @author nithnaik
 *
 */
public class UploadResult {
  private List<String> files;

  private String content;

  /**
   * The constructor.
   *
   * @param files
   */
  public UploadResult(List<String> files, String content) {
    super();
    this.files = files;
    this.content = content;
  }

  public UploadResult() {

  }

  /**
   * @return content
   */
  public String getContent() {

    return this.content;
  }

  /**
   * @param content new value of {@link #getcontent}.
   */
  public void setContent(String content) {

    this.content = content;
  }

  /**
   * @return files
   */
  public List<String> getFiles() {

    return this.files;
  }

  /**
   * @param files new value of {@link #getfiles}.
   */
  public void setFiles(List<String> files) {

    this.files = files;
  }

}
