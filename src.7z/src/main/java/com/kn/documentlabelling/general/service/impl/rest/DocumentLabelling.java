package com.kn.documentlabelling.general.service.impl.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author nithnaik
 *
 */
@Controller
@RequestMapping("/files")
public class DocumentLabelling {

  @GET
  @Path("/textContent")
  @Produces({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM,
  MediaType.MEDIA_TYPE_WILDCARD, MediaType.TEXT_HTML, MediaType.MULTIPART_FORM_DATA })
  public ResponseEntity downloadFile() throws IOException {

    ClassPathResource pdfFile = new ClassPathResource("aaa.txt");

    HttpHeaders headers = new HttpHeaders();
    headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
    headers.add("Pragma", "no-cache");
    headers.add("Expires", "0");

    return ResponseEntity.ok().headers(headers).contentLength(pdfFile.contentLength())
        .body(new InputStreamResource(pdfFile.getInputStream()));

  }

  public static void main(String[] args) throws IOException {

    ClassPathResource file = new ClassPathResource("aaa.txt");

    byte[] b = new byte[1024];
    int bytes = file.getInputStream().read(b);
    System.out.println(bytes);
  }

  @RequestMapping(value = "/paths", method = RequestMethod.GET)
  @Produces({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM,
  MediaType.MEDIA_TYPE_WILDCARD, MediaType.TEXT_HTML, MediaType.MULTIPART_FORM_DATA })
  public ResponseEntity<String> downloadPDFFile() throws IOException {

    ClassPathResource pdfFile = new ClassPathResource("aaa.txt");

    // InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("D://aaa.txt");

    File file = new File("D:/aaa.txt");
    byte[] bytes = loadFile(file);
    byte[] encoded = org.apache.commons.codec.binary.Base64.encodeBase64(bytes);
    String encodedString = new String(encoded);

    HttpHeaders headers = new HttpHeaders();
    headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
    headers.add("Pragma", "no-cache");
    headers.add("Expires", "0");

    return ResponseEntity.ok().headers(headers).contentLength(100).body(encodedString);
  }

  private static byte[] loadFile(File file) throws IOException {

    InputStream is = new FileInputStream(file);

    long length = file.length();
    if (length > Integer.MAX_VALUE) {
      // File is too large
    }
    byte[] bytes = new byte[(int) length];

    int offset = 0;
    int numRead = 0;
    while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
      offset += numRead;
    }

    if (offset < bytes.length) {
      throw new IOException("Could not completely read file " + file.getName());
    }

    is.close();
    return bytes;
  }

  @RequestMapping(value = "/lists", method = RequestMethod.GET)
  @Produces({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM,
  MediaType.MEDIA_TYPE_WILDCARD, MediaType.TEXT_HTML, MediaType.MULTIPART_FORM_DATA })
  public @ResponseBody Map getFile() throws JSONException, IOException {

    File file = new ClassPathResource("Tulips.jpg").getFile();

    String encodeImage =
        Base64.getEncoder().withoutPadding().encodeToString(java.nio.file.Files.readAllBytes(file.toPath()));

    Map<String, String> jsonMap = new HashMap();

    jsonMap.put("content", encodeImage);

    return jsonMap;

    // JSONObject jsonObject = new JSONObject();
    // UploadResult result = new UploadResult();
    // List<String> files = new ArrayList<String>();
    // try {
    //
    // Class.forName("com.mysql.jdbc.Driver");
    // Connection cn =
    // DriverManager.getConnection("jdbc:mysql://localhost:3306/aisservice_locEnvDB", "root", "admin");
    // Statement st = cn.createStatement();
    // ResultSet resultSet = st.executeQuery("select file_name from aisservice_locEnvDB.FILES");
    // while (resultSet.next()) {
    // String file_name = resultSet.getString("file_name");
    // files.add(file_name);
    // }
    //
    // System.out.println("Files" + files);
    //
    // } catch (ClassNotFoundException e) {
    // e.printStackTrace();
    // } catch (SQLException e) {
    // e.printStackTrace();
    // }
    // result.setFiles(files);
    // return result;

  }

  /*
   * @RequestMapping(value = "/filesPath", method = RequestMethod.GET)
   *
   * @Produces(MediaType.APPLICATION_JSON)
   *
   * @ResponseBody public HashMap homes() throws IOException {
   *
   * JSONObject jsonObject = new JSONObject(); List<String> files = new ArrayList<String>(); try {
   *
   * Class.forName("com.mysql.jdbc.Driver"); Connection cn =
   * DriverManager.getConnection("jdbc:mysql://localhost:3306/documentlabelling_locEnvDB", "root", "root"); Statement st
   * = cn.createStatement(); ResultSet resultSet =
   * st.executeQuery("select file_name from documentlabelling_locEnvDB.FILES"); while (resultSet.next()) { String
   * file_name = resultSet.getString("file_name"); files.add(file_name); }
   *
   * System.out.println("Files" + files);
   *
   * } catch (ClassNotFoundException e) { e.printStackTrace(); } catch (SQLException e) { e.printStackTrace(); } //
   * jsonObject.put("files", files);
   *
   * Map hs = new HashMap(); for (String file : files) { // // System.out.println(file.getName());
   *
   * hs.put("files", file); }
   *
   * return (HashMap) hs; }
   */

  /**
   * @param file_name
   * @return
   * @throws JSONException
   * @throws SQLException
   */
  @RequestMapping(value = "/contents", method = RequestMethod.GET)
  @Produces({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM,
  MediaType.MEDIA_TYPE_WILDCARD, MediaType.TEXT_HTML, MediaType.MULTIPART_FORM_DATA })

  public @ResponseBody UploadResult getFileContents() throws JSONException, SQLException {

    JSONObject jsonObject = new JSONObject();
    Connection cn = null;
    ResultSet rs = null;
    UploadResult uploadResult = new UploadResult();
    String s = null;
    List<String> files = new ArrayList<String>();
    try {

      Class.forName("com.mysql.jdbc.Driver");
      cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aisservice_locEnvDB", "root", "admin");
      PreparedStatement preparedStatement =
          cn.prepareStatement("select file_content from aisservice_locEnvDB.FILES where file_name = ?");
      preparedStatement.setString(1, "aaa.txt");
      rs = preparedStatement.executeQuery();
      while (rs.next()) {
        Blob blob = rs.getBlob("file_content");
        System.out.println("BLOB::::::::::" + blob);
        byte[] bdata = blob.getBytes(1, (int) blob.length());
        s = new String(bdata);
        System.out.println("S:::::::::::::::::::::::::" + s);
      }

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      cn.close();
      rs.close();

    }
    uploadResult.setContent(s);
    return uploadResult;

  }

}