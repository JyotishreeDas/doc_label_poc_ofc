package com.kn.documentlabelling.dl.common.api;

import com.kn.documentlabelling.general.common.api.ApplicationEntity;

/**
 * @author nithnaik
 *
 */
public interface Document extends ApplicationEntity {

}
