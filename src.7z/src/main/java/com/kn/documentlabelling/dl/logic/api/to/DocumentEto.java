/*
 * package com.kn.documentlabelling.dl.logic.api.to;
 * 
 * import com.kn.documentlabelling.dl.common.api.Document; import
 * com.kn.documentlabelling.general.common.api.to.AbstractEto;
 * 
 *//**
   * Entity transport object of Document
   *//*
     * public class DocumentEto extends AbstractEto implements Document {
     * 
     * private static final long serialVersionUID = 1L;
     * 
     * private Long id;
     * 
     * private String fileName;
     * 
     * private Long fileSize;
     * 
     * private byte[] fileContent;
     * 
     * @Override public Long getId() {
     * 
     * return id; }
     * 
     * @Override public void setId(Long id) {
     * 
     * this.id = id; }
     * 
     * @Override public String getFileName() {
     * 
     * return fileName; }
     * 
     * @Override public void setFileName(String fileName) {
     * 
     * this.fileName = fileName; }
     * 
     * @Override public Long getFileSize() {
     * 
     * return fileSize; }
     * 
     * @Override public void setFileSize(Long fileSize) {
     * 
     * this.fileSize = fileSize; }
     * 
     * @Override public byte[] getFileContent() {
     * 
     * return fileContent; }
     * 
     * @Override public void setFileContent(byte[] fileContent) {
     * 
     * this.fileContent = fileContent; }
     * 
     * @Override public int hashCode() {
     * 
     * final int prime = 31; int result = super.hashCode(); result = prime * result + ((this.id == null) ? 0 :
     * this.id.hashCode()); result = prime * result + ((this.fileName == null) ? 0 : this.fileName.hashCode()); result =
     * prime * result + ((this.fileSize == null) ? 0 : this.fileSize.hashCode()); result = prime * result +
     * ((this.fileContent == null) ? 0 : this.fileContent.hashCode()); return result; }
     * 
     * @Override public boolean equals(Object obj) {
     * 
     * if (this == obj) { return true; } if (obj == null) { return false; } // class check will be done by super type
     * EntityTo! if (!super.equals(obj)) { return false; } DocumentEto other = (DocumentEto) obj; if (this.id == null) {
     * if (other.id != null) { return false; } } else if (!this.id.equals(other.id)) { return false; } if (this.fileName
     * == null) { if (other.fileName != null) { return false; } } else if (!this.fileName.equals(other.fileName)) {
     * return false; } if (this.fileSize == null) { if (other.fileSize != null) { return false; } } else if
     * (!this.fileSize.equals(other.fileSize)) { return false; } if (this.fileContent == null) { if (other.fileContent
     * != null) { return false; } } else if (!this.fileContent.equals(other.fileContent)) { return false; } return true;
     * } }
     */