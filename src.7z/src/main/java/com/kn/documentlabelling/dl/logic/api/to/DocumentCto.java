/*
 * package com.kn.documentlabelling.dl.logic.api.to;
 * 
 * import com.kn.documentlabelling.general.common.api.to.AbstractCto;
 * 
 *//**
   * Composite transport object of Document
   *//*
     * public class DocumentCto extends AbstractCto {
     * 
     * private static final long serialVersionUID = 1L;
     * 
     * private DocumentEto document;
     * 
     * public DocumentEto getDocument() {
     * 
     * return document; }
     * 
     * public void setDocument(DocumentEto document) {
     * 
     * this.document = document; }
     * 
     * }
     */