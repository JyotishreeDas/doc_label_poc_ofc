package com.kn.documentlabelling.dl.common.api.utill;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;

/**
 * @author ujjjha
 *
 */
public class FileToTextConverter {

  public String convertFileToText(InputStream fis) throws SAXException, TikaException {

    String content = "";
    /*
     * // System.out.println("File Name "+filename); String fName = "D:\\Files\\" + filename;
     *
     * File file = new File(fName);
     *
     * String fileName = file.getName();
     *
     * FileInputStream fis = null;
     *
     * int index = fileName.lastIndexOf('.'); String fileExtension = fileName.substring(index + 1); //
     * System.out.println("fileExtension "+fileExtension);
     */
    try {

      // fis = new FileInputStream(file);
      if (fis == null) {
        return null;
      }

      System.out.println("Total file size to read (in bytes) : " + fis.available());

      /*
       * if ("jpeg".equals(fileExtension) || "jpg".equals(fileExtension) || "png".equals(fileExtension)) { String
       * content = processImage(file); }
       */
      content = processFile(fis);
      fis = null;
      System.out.println("content-----------------" + content);
    } catch (IOException e) {
      e.printStackTrace();
    }
    return content;
  }

  public String processFile(InputStream fis) throws IOException, SAXException {

    // System.out.println("Calling processFile to convert All to TEXT");
    AutoDetectParser parser = new AutoDetectParser();
    BodyContentHandler handler = new BodyContentHandler();
    Metadata metadata = new Metadata();

    InputStream stream = fis;
    try {
      parser.parse(stream, handler, metadata);
    } catch (TikaException e) {
      e.printStackTrace();
    }
    return handler.toString();
  }


  /*
   * public String processImage(File file) { System.out.println("Calling processImage to convert IMAGE to TEXT");
   *
   * String result = ""; try { Tesseract instance = new Tesseract(); File tessDataFolder =
   * LoadLibs.extractTessResources("tessdata"); String path = tessDataFolder.getAbsolutePath();
   * instance.setDatapath(path); result = instance.doOCR(file); } catch (TesseractException e) { e.printStackTrace(); }
   * return result; }
   */
}
