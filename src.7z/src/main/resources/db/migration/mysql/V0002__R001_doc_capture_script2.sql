-- *** DOCUMENT ***

CREATE TABLE `files` (
  `ID` bigint(20) NOT NULL,
  `file_name` varchar(64) NOT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_content` longblob,
  `MODIFICATIONCOUNTER` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
)






