
-- *** BinaryObject (BLOBs) ***
CREATE TABLE BinaryObject (
  id BIGINT NOT NULL AUTO_INCREMENT,
  modificationCounter INTEGER NOT NULL,
  data BLOB(2147483647),
  size BIGINT NOT NULL,
  mimeType VARCHAR(255),
  PRIMARY KEY (ID)
);

-- *** RevInfo (Commit log for envers audit trail) ***
CREATE TABLE REVINFO(
    id BIGINT(10) NOT NULL,
    timestamp BIGINT(10) NOT NULL,
    user VARCHAR(40) NOT NULL
);

-- *** DOCUMENT ***






