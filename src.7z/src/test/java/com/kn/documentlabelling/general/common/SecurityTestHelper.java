package com.kn.documentlabelling.general.common;

/**
 * This class provides security related operations to facilitate testing.
 *
 * @author jmolinar
 */

public class SecurityTestHelper {

  /**
   * The constructor.
   */
  public SecurityTestHelper() {
    super();
  }

  public void login(String name) {

    // TODO implement in later iteration
  }

  public void logout() {

    // TODO implement in later iteration
  }

}
