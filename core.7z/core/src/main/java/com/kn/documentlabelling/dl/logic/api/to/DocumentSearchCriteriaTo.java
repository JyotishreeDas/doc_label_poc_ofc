package com.kn.documentlabelling.dl.logic.api.to;

import io.oasp.module.jpa.common.api.to.SearchCriteriaTo;

/**
 * This is the {@link SearchCriteriaTo search criteria} {@link net.sf.mmm.util.transferobject.api.TransferObject TO}
 * used to find {@link com.kn.documentlabelling.dl.common.api.Document}s.
 *
 */
public class DocumentSearchCriteriaTo extends SearchCriteriaTo {

  private static final long serialVersionUID = 1L;

  private Long id;

  private String fileName;

  private Long fileSize;

  private byte[] fileContent;

  /**
   * The constructor.
   */
  public DocumentSearchCriteriaTo() {

    super();
  }

  public Long getId() {

    return id;
  }

  public void setId(Long id) {

    this.id = id;
  }

  public String getFileName() {

    return fileName;
  }

  public void setFileName(String fileName) {

    this.fileName = fileName;
  }

  public Long getFileSize() {

    return fileSize;
  }

  public void setFileSize(Long fileSize) {

    this.fileSize = fileSize;
  }

  public byte[] getFileContent() {

    return fileContent;
  }

  public void setFileContent(byte[] fileContent) {

    this.fileContent = fileContent;
  }

}
