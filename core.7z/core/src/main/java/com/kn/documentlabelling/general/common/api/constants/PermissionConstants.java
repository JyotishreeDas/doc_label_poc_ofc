package com.kn.documentlabelling.general.common.api.constants;

/**
 * Contains constants for the keys of all
 * {@link io.oasp.module.security.common.api.accesscontrol.AccessControlPermission}s.
 *
 * @author jmetzler
 */
public abstract class PermissionConstants {

  // put your permission names from access-control-schema.xml as constants here (or generate with cobigen)
  
}
