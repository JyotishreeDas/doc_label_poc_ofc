package com.kn.documentlabelling.general.common.api;

/**
 * A marker interface for REST services. REST service interfaces of components should extend this interface.
 *
 * @author jmolinar
 */
public interface RestService {

}
