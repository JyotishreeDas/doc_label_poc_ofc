package com.kn.documentlabelling.dl.common.api.constants;

/**
 * @author nithnaik
 *
 */
public interface DocumentNamedQueries {

  /**
   *
   */
  public static final String GET_FILES_BY_NAME = "get.files.by.name";

  /**
   *
   */
  public static final String GET_FILE_CONTENT_BY_NAME = "get.filecontent.by.filename";

  public static final String GET_FILE_CONTENT_BY_NAME_FORTEXT = "get.filecontent.by.filename.fortext";
}
