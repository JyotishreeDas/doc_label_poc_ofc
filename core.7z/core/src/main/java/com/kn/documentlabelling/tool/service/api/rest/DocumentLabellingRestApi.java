package com.kn.documentlabelling.tool.service.api.rest;

import java.io.IOException;
import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author annjosep
 *
 */
@Path("/documentlabellingservice")
@Produces(MediaType.APPLICATION_JSON)
public interface DocumentLabellingRestApi {

  /**
   * @return
   */
  @GET
  @Path("/documentList")
  public Response documentList();

  @POST
  @Path("/documentContent/{fileName}")
  public Response documentContent(@PathParam("fileName") String fileName) throws IOException, SQLException;

}
